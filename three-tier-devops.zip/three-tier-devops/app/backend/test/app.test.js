const test = require('node:test');
const assert = require('node:assert');
const { createApp } = require('../src/app');

function start(pool) {
  return new Promise((resolve) => {
    const server = createApp(pool).listen(0, () => resolve(server));
  });
}

test('GET /health returns ok', async () => {
  const server = await start({ query: async () => ({ rows: [] }) });
  const res = await fetch(`http://127.0.0.1:${server.address().port}/health`);
  assert.strictEqual(res.status, 200);
  assert.deepStrictEqual(await res.json(), { status: 'ok' });
  server.close();
});

test('GET /api/hello returns DB time', async () => {
  const server = await start({ query: async () => ({ rows: [{ time: '2026-01-01T00:00:00Z' }] }) });
  const res = await fetch(`http://127.0.0.1:${server.address().port}/api/hello`);
  assert.strictEqual(res.status, 200);
  assert.strictEqual((await res.json()).dbTime, '2026-01-01T00:00:00Z');
  server.close();
});

test('GET /api/hello returns 503 when DB is down', async () => {
  const server = await start({ query: async () => { throw new Error('boom'); } });
  const res = await fetch(`http://127.0.0.1:${server.address().port}/api/hello`);
  assert.strictEqual(res.status, 503);
  server.close();
});
