const express = require('express');

// The DB pool is injected so the app can be tested without a real database.
function createApp(pool) {
  const app = express();

  // Liveness check used by the ALB target group. Deliberately does not touch the DB.
  app.get('/health', (_req, res) => res.json({ status: 'ok' }));

  app.get('/api/hello', async (_req, res) => {
    try {
      const result = await pool.query('SELECT now() AS time');
      res.json({ message: 'Hello from the API', dbTime: result.rows[0].time });
    } catch (err) {
      console.error(JSON.stringify({ level: 'error', msg: 'db query failed', error: err.message }));
      res.status(503).json({ message: 'Hello from the API', db: 'unavailable' });
    }
  });

  return app;
}

module.exports = { createApp };
