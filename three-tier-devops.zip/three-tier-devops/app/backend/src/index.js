const { Pool } = require('pg');
const { createApp } = require('./app');

const pool = new Pool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT || 5432),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  // RDS enforces TLS. rejectUnauthorized=false keeps the demo simple;
  // production should ship the RDS CA bundle and verify it.
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
  max: 5,
});

const port = Number(process.env.PORT || 3000);
createApp(pool).listen(port, '0.0.0.0', () => {
  console.log(JSON.stringify({ level: 'info', msg: `api listening on ${port}` }));
});
