terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.60"
    }
  }

  # For a team setup, use remote state with locking (see README, production section):
  # backend "s3" {
  #   bucket         = "<state-bucket>"
  #   key            = "three-tier/dev/terraform.tfstate"
  #   region         = "eu-central-1"
  #   dynamodb_table = "<lock-table>"
  #   encrypt        = true
  # }
}

provider "aws" {
  region = var.aws_region

  # Tagging convention applied to every taggable resource.
  default_tags {
    tags = {
      Project     = var.project
      Environment = var.environment
      ManagedBy   = "terraform"
    }
  }
}
