data "aws_caller_identity" "current" {}

data "aws_availability_zones" "available" {
  state = "available"
}

locals {
  name_prefix    = "${var.project}-${var.environment}"
  azs            = slice(data.aws_availability_zones.available.names, 0, 2)
  container_port = 3000
  db_name        = "appdb"
  db_username    = "appuser"
}

module "network" {
  source = "../../modules/network"

  name_prefix    = local.name_prefix
  vpc_cidr       = var.vpc_cidr
  azs            = local.azs
  container_port = local.container_port
}

module "rds" {
  source = "../../modules/rds"

  name_prefix    = local.name_prefix
  vpc_id         = module.network.vpc_id
  subnet_ids     = module.network.private_subnet_ids
  app_sg_id      = module.network.app_sg_id
  db_name        = local.db_name
  db_username    = local.db_username
  instance_class = "db.t4g.micro"
}

module "ecs" {
  source = "../../modules/ecs"

  name_prefix        = local.name_prefix
  aws_region         = var.aws_region
  vpc_id             = module.network.vpc_id
  public_subnet_ids  = module.network.public_subnet_ids
  private_subnet_ids = module.network.private_subnet_ids
  alb_sg_id          = module.network.alb_sg_id
  app_sg_id          = module.network.app_sg_id
  container_port     = local.container_port
  db_host            = module.rds.address
  db_port            = module.rds.port
  db_name            = local.db_name
  db_secret_arn      = module.rds.secret_arn
}

module "frontend" {
  source = "../../modules/frontend"

  name_prefix  = local.name_prefix
  account_id   = data.aws_caller_identity.current.account_id
  alb_dns_name = module.ecs.alb_dns_name
}

module "monitoring" {
  source = "../../modules/monitoring"

  name_prefix    = local.name_prefix
  alarm_email    = var.alarm_email
  alb_arn_suffix = module.ecs.alb_arn_suffix
  tg_arn_suffix  = module.ecs.target_group_arn_suffix
  cluster_name   = module.ecs.cluster_name
  service_name   = module.ecs.service_name
}

module "cicd" {
  source = "../../modules/cicd"

  name_prefix          = local.name_prefix
  github_repo          = var.github_repo
  create_oidc_provider = var.create_github_oidc_provider
  ecr_repository_arn   = module.ecs.ecr_repository_arn
  ecs_service_arn      = "arn:aws:ecs:${var.aws_region}:${data.aws_caller_identity.current.account_id}:service/${module.ecs.cluster_name}/${module.ecs.service_name}"
  task_role_arns       = [module.ecs.task_execution_role_arn, module.ecs.task_role_arn]
  frontend_bucket_arn  = module.frontend.bucket_arn
  cloudfront_arn       = module.frontend.distribution_arn
}
