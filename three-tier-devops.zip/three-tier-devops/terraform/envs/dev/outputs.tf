output "frontend_url" {
  description = "Public URL of the application (CloudFront)."
  value       = "https://${module.frontend.domain_name}"
}

output "alb_dns_name" {
  description = "ALB DNS name (only reachable from CloudFront)."
  value       = module.ecs.alb_dns_name
}

output "github_actions_variables" {
  description = "Set each of these as a GitHub repository variable (Settings > Secrets and variables > Actions > Variables)."
  value = {
    AWS_REGION                 = var.aws_region
    AWS_ROLE_ARN               = module.cicd.role_arn
    ECR_REPOSITORY             = module.ecs.ecr_repository_name
    ECS_CLUSTER                = module.ecs.cluster_name
    ECS_SERVICE                = module.ecs.service_name
    ECS_TASK_FAMILY            = module.ecs.task_family
    FRONTEND_BUCKET            = module.frontend.bucket_name
    CLOUDFRONT_DISTRIBUTION_ID = module.frontend.distribution_id
  }
}
