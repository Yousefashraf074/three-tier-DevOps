variable "project" {
  description = "Project name, used as the first part of every resource name."
  type        = string
  default     = "threetier"
}

variable "environment" {
  description = "Environment name (dev, staging, prod)."
  type        = string
  default     = "dev"
}

variable "aws_region" {
  description = "AWS region to deploy into."
  type        = string
  default     = "eu-central-1"
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC."
  type        = string
  default     = "10.0.0.0/16"
}

variable "alarm_email" {
  description = "Email address that receives CloudWatch alarm notifications."
  type        = string
}

variable "github_repo" {
  description = "GitHub repository allowed to deploy, as owner/name."
  type        = string
}

variable "create_github_oidc_provider" {
  description = "Set to false if the GitHub OIDC provider already exists in the account."
  type        = bool
  default     = true
}
