variable "name_prefix" {
  type = string
}

variable "account_id" {
  description = "Used to make the bucket name globally unique."
  type        = string
}

variable "alb_dns_name" {
  description = "Origin for /api/* requests."
  type        = string
}
