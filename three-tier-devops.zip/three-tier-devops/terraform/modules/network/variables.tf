variable "name_prefix" {
  type = string
}

variable "vpc_cidr" {
  type = string
}

variable "azs" {
  description = "Two availability zones."
  type        = list(string)
}

variable "container_port" {
  type = number
}
