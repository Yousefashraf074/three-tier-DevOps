variable "name_prefix" {
  type = string
}

variable "alarm_email" {
  type = string
}

variable "alb_arn_suffix" {
  type = string
}

variable "tg_arn_suffix" {
  type = string
}

variable "cluster_name" {
  type = string
}

variable "service_name" {
  type = string
}
