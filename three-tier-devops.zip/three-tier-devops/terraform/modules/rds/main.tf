resource "aws_security_group" "db" {
  name_prefix = "${var.name_prefix}-db-"
  description = "PostgreSQL: from the application security group only"
  vpc_id      = var.vpc_id

  tags = { Name = "${var.name_prefix}-db-sg" }

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_ingress_rule" "db_from_app" {
  security_group_id            = aws_security_group.db.id
  description                  = "PostgreSQL from ECS tasks"
  referenced_security_group_id = var.app_sg_id
  ip_protocol                  = "tcp"
  from_port                    = 5432
  to_port                      = 5432
}

resource "aws_db_subnet_group" "this" {
  name       = "${var.name_prefix}-db-subnets"
  subnet_ids = var.subnet_ids

  tags = { Name = "${var.name_prefix}-db-subnets" }
}

resource "aws_db_instance" "this" {
  identifier     = "${var.name_prefix}-postgres"
  engine         = "postgres"
  engine_version = "16"
  instance_class = var.instance_class

  allocated_storage = 20
  storage_type      = "gp3"
  storage_encrypted = true

  db_name  = var.db_name
  username = var.db_username

  # RDS generates the password and stores it in Secrets Manager.
  # It never appears in code, tfvars, or CI variables.
  manage_master_user_password = true

  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = [aws_security_group.db.id]
  publicly_accessible    = false
  multi_az               = false # single-AZ for the assessment; see README

  backup_retention_period    = 1
  auto_minor_version_upgrade = true

  # Assessment-friendly: allows a clean `terraform destroy`.
  skip_final_snapshot = true
  deletion_protection = false

  tags = { Name = "${var.name_prefix}-postgres" }
}
