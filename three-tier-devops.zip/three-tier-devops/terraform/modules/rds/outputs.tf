output "address" {
  value = aws_db_instance.this.address
}

output "port" {
  value = aws_db_instance.this.port
}

output "secret_arn" {
  description = "ARN of the RDS-managed Secrets Manager secret (JSON with username and password)."
  value       = aws_db_instance.this.master_user_secret[0].secret_arn
}
