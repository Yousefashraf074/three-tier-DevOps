variable "name_prefix" {
  type = string
}

variable "github_repo" {
  description = "owner/name of the repository allowed to assume the deploy role."
  type        = string
}

variable "create_oidc_provider" {
  type    = bool
  default = true
}

variable "ecr_repository_arn" {
  type = string
}

variable "ecs_service_arn" {
  type = string
}

variable "task_role_arns" {
  description = "Roles the pipeline may pass to ECS when registering a task definition."
  type        = list(string)
}

variable "frontend_bucket_arn" {
  type = string
}

variable "cloudfront_arn" {
  type = string
}
